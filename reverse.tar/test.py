%matplotlib inline
%config InlineBackend.figure_format = 'svg'

import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

mpl.style.use('ggplot')
x = np.linspace(0,10,50)
plt.plot(x, np.sin(x) + np.cos(0.5 * x))
plt.show()

def fun()
    """
    comment
    """
    return 0


def function():

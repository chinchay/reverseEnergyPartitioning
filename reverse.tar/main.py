# Comment

import potential



# import functions
# functions.getForceMatrix()
# assert functions.harmonicDOS(1, 1) == 17.771531752633464
